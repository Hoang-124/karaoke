const Room = require('../Models/roomModel');
const Booking = require('../Models/bookingModel');

exports.getAllBookings = async (req, res) => {
    const bookings = await Booking.find();
    res.render('booking', { bookings });
};

exports.getAddBooking = (req, res) => res.render('bookRoom', { booking: null });

exports.postAddBooking = async (req, res) => {
    const { customerName, roomNumber, startTime, endTime } = req.body;
    const room = await Room.findOne({ roomNumber });
    if (!room) return res.send('Phòng không tồn tại!');
    const hours = (new Date(endTime) - new Date(startTime)) / (1000 * 60 * 60);
    await Booking.create({ customerName, roomNumber, startTime, endTime, totalAmount: hours * room.pricePerHour });
    res.redirect('/bookings');
};

exports.postDeleteBooking = async (req, res) => {
    await Booking.findByIdAndDelete(req.params.id);
    res.redirect('/bookings');
};

exports.getUpdateBooking = async (req, res) => {
    const booking = await Booking.findById(req.params.id);
    res.render('updateRoom', { booking });
};

exports.postUpdateBooking = async (req, res) => {
    const { customerName, roomNumber, startTime, endTime } = req.body;
    const room = await Room.findOne({ roomNumber });
    const hours = (new Date(endTime) - new Date(startTime)) / (1000 * 60 * 60);
    await Booking.findByIdAndUpdate(req.params.id, { customerName, roomNumber, startTime, endTime, totalAmount: hours * room.pricePerHour });
    res.redirect('/bookings');
};