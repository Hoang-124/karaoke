const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const bookingController = require('./Controllers/bookingController');

app.set('views', path.join(__dirname, 'Views'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/karaokeDB');

app.get('/', (req, res) => res.redirect('/bookings'));
app.get('/bookings', bookingController.getAllBookings);
app.get('/book-room', bookingController.getAddBooking);
app.post('/book-room', bookingController.postAddBooking);
app.post('/delete-booking/:id', bookingController.postDeleteBooking);
app.get('/update-booking/:id', bookingController.getUpdateBooking);
app.post('/update-booking/:id', bookingController.postUpdateBooking);

app.listen(3000, () => console.log('Server chạy tại http://localhost:3000'));